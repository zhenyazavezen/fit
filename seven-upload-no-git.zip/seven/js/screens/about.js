import { h, icon } from '../util.js';
import { t } from '../i18n.js';
import { CONFIG, BUILD } from '../config.js';
import { tg } from '../tg.js';
import { topbar, noteBox } from '../ui.js';

export default function about() {
  const el = h('div');
  el.append(topbar({ title: t('about.title') }),
    h('div', { class: 'pad stack' },
      h('div', null, h('div', { class: 'h1' }, CONFIG.appName), h('div', { class: 'small muted', style: { marginTop: '4px' } }, t('about.version', { version: CONFIG.version }) + (BUILD !== 'dev' ? ` · ${BUILD.slice(0, 7)}` : ''))),
      h('div', { class: 'prose' }, h('p', null, t('about.how')), h('p', null, t('about.storage'))),
      noteBox(t('about.preview')),
      h('h2', { class: 'h3' }, t('about.important')),
      h('div', { class: 'prose' }, h('p', null, t('about.content'))),
      h('h2', { class: 'h3' }, t('about.license')),
      h('div', { class: 'prose' }, h('p', null, t('about.licenseText'))),
      h('button', { class: 'btn ghost', onClick: () => tg.openLink('https://github.com/ashwinr93/workout') }, icon('external', 18), t('about.original'))));
  return { el };
}
